package org.xutils.ex;

/**
 * Created by wyouflf on 15/10/9.
 */
public class CacheLockedException extends BaseException {
    private static final long serialVersionUID = 1L;

    public CacheLockedException(String detailMessage) {
        super(detailMessage);
    }
}
